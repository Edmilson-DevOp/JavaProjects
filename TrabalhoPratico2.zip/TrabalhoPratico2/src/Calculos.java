
public class Calculos {
	public Calculos()
	{
		
	}

	public int calcularQuantidadesReservaTipo(Reserva[] array, int cont, String tipo) {
		// TODO Auto-generated method stub
		int quant = 0;
        
        for(int i=0;i<cont;i++)
        {
            
          if(array[i].getTipoReserva().equalsIgnoreCase(tipo))
             quant++;
        }
    return quant;
	}

	public int somaQuantidadesTotalReserva(int totalEmpresa, int totalCasal, int totalParticular) {
		// TODO Auto-generated method stub
		 return totalEmpresa + totalCasal + totalParticular;
	}

	public float convMoeda(float val) {
		// TODO Auto-generated method stub
		final byte CAMBIO = 65; 
        return val * CAMBIO;
	}

	public float calcularValTotal(Reserva[] array, int cont, String tipo) {
		// TODO Auto-generated method stub
		float val = 0;
		for (int i = 0; i < cont; i++)
			if(array[i].getTipoReserva().equalsIgnoreCase(tipo))
				val += array[i].getValFinal();
		return val;
	}

	public void pesquisarReserva(Reserva[] array, int cont) {
		// TODO Auto-generated method stub
		int num, index;
		String tipo = " ";
		Validacoes val = new Validacoes();
		Visualizacoes visu = new Visualizacoes();
		num = val.validarInteiros(820000000, 879999999, "Introduza o numero de telefone:");
		tipo = val.validarTipoReserva("empresa", "casal", "particular", "Introduza o tipo de reserva: ");
		index = buscarIndex(array, cont, num, tipo);
		if(index == -1)
			System.out.println("Reserva não encontrada!");
		else
			visu.visualizarPeloTipoNum(index,array);
			
	}

	private int buscarIndex(Reserva[] array, int cont, int num, String tipo) {
		// TODO Auto-generated method stub
		   boolean busca = false;
           
           for(int i=0; i<cont; i++)
           {
                       if(array[i].getTelefone() == num && array[i].getTipoReserva() == tipo)
                           busca = true;
                           System.out.println(array[i]);
           }
           return -1;
	}

}
