/*
 * @author Ayko Sambo - 20190217
 * @author Edmilson Leandro - 20190723 
 * @author Ilundy Simbine - 20241112 
 */
public class Executavel {
	public static void main(String[] args)
	{
		Menu m = new Menu();
        m.run();
    }
}
