import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;
public class Visualizacoes {
	private DecimalFormat mt;
    private NumberFormat usd;
    
	public Visualizacoes()
	{
		mt = new DecimalFormat("###,###.00 MTS");
        usd = NumberFormat.getCurrencyInstance(Locale.US);
	}

	public String toString(Reserva[] array, int cont) {
		// TODO Auto-generated method stub
		String dados = "";

        for(int i=0;i<cont;i++)
        {
           dados += array[i] + "\n";	
        }
        return dados;
	}

	public void visualizarQuantidades(int cont, String tipo) {
		// TODO Auto-generated method stub
		System.out.println("|----Quantidade total das Reservas ---|");
		System.out.println("|---------------------------------------|");
		System.out.println("|       Reservas de "+(tipo)+"             ");
		System.out.println("|---------------------------------------|");
		System.out.printf("|%39d|\n", cont);
		System.out.println("|---------------------------------------|");
	}

	public void menuOpcoes() {
		// TODO Auto-generated method stub
        System.out.println();
		System.out.println("|------------------------------------------------------------------------------------------|");
		System.out.println("|------------------------------------------------------------------------------------------|");
		System.out.println("|                          --------- Bem-Vindo  ao Hotel Maricell Lodge----------          |");
		System.out.println("|------------------------------------------------------------------------------------------|");
		System.out.println("| 1-Ler do ficheiro de texto, todos os dados das Reservas.                                 |");
		System.out.println("| 2-Visualizar todas reservas de forma Separada.                                            |");
		System.out.println("| 3-Visualizar a quantidade de reservas por cada tipo.                                    |");
		System.out.println("| 4- Visualizar as reservas de feriados do mês de Setembro[To Do]                         |");
		System.out.println("| 5-Escrever em um ficheiro de texto o valor  recebido por cada tipo em USD e MTn.         |");
		System.out.println("| 6- Escrever os dados em um ficheiro de objectos                                          |");
		System.out.println("| 7-Pesquisar  reserva pelo número de telefone e pelo tipo de reserva                     |");
		System.out.println("| 8-Ordenar as reservas de forma decrescente da data de saída                             |");
		System.out.println("| 9 - (BONUS) Adicionar nova reserva a partir do teclado e acrescentar no ficheiro de texto|");
                                          System.out.println("| 10 - Sair                                                        |");
                                          System.out.println("|------------------------------------------------------------------------------------------|");
		System.out.println("|------------------------------------------------------------------------------------------|");
		System.out.println();
	}

	public void subMenu() {
		// TODO Auto-generated method stub
        System.out.println();
        System.out.println("|------------------------------------------------------------------------------|");
        System.out.println("|------------------------------------------------------------------------------|");
        System.out.println("|                           Mini Menu ao Hotel Maricell Lodge                           |");
        System.out.println("|------------------------------------------------------------------------------|");
                                         System.out.println("|1- Empresa|");
                                         System.out.println("|2- Casal |");
                                         System.out.println("|3- Particular|");
                                         System.out.println("|4 - Voltar |");
       System.out.println("|------------------------------------------------------------------------------|");
       System.out.println();
	}

	public void visualizarReservasEmpresa(Reserva[] array, int cont) {
		// TODO Auto-generated method stub
		for(int i=0; i< cont; i++)
        {
                    if(array[i].getTipoReserva().equalsIgnoreCase("Empresa"))
                    {
                    	System.out.println();
                    	System.out.println("|------------------------------------------------------------------------------------------------------------------------------------------------|");
                    	System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|");
                    	System.out.println("|  Numero Cell |    Nome    |  Tipo Reserva  | Qty Pessoas| Data Entrada |  Data Saida |   Valor a Pagar(USD)| Valor a Pagar(Mt) |");
                    	System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|");
                    	System.out.printf("|%17s|%12s|%12s|%19d|%19s|%20s|%19s|%19s|\n", array[i].getTelefone(),array[i].getNomeCliente(),array[i].getTipoReserva(), array[i].getNumPessoas(), array[i].getDataEntrada(),array[i].getDataSaida(),usd.format(array[i].getValPagar()),mt.format(array[i].getValPagarMT()));
                    	System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|");
                    	System.out.println("|------------------------------------------------------------------------------------------------------------------------------------------------|");
                    	System.out.println();
                    }
        }
	}

	public void visualizarReservasCasal(Reserva[] array, int cont) {
		// TODO Auto-generated method stub
		for(int i=0; i<cont; i++)
        {
                if(array[i].getTipoReserva().equalsIgnoreCase("Casal"))
                {
                	System.out.println();
                	System.out.println("|------------------------------------------------------------------------------------------------------------------------------------------------|");
                	System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|");
                	System.out.println("|  Numero Cell |    Nome    |  Tipo Reserva  | Turista| Qty Pessaos |  Data Entrada |   Data Saida| Valor a Pagar (USD) | Valor a Pagar (MT)|");
                	System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|");
                	System.out.printf("|%17s|%12s|%12d|%19d|%19s|%20s|%19s|%19s| %20s|\n", array[i].getTelefone(),array[i].getNomeCliente(),array[i].getTipoReserva(), array[i].getNumPessoas(), array[i].getDataEntrada(),array[i].getDataSaida(), usd.format(array[i].getValPagar()));
                	System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|--------------------|");
                	System.out.println("|--------------------------------------------------------------------------------------------------------------------------------------------------------------------|");
                	System.out.println();
                }
        }
	}

	public void visualizarReservasParticular(Reserva[] array, int cont) {
		// TODO Auto-generated method stub
		 for(int i=0; i<cont; i++)
         {
                 if(array[i].getTipoReserva().equalsIgnoreCase("Particular"))
                 {  
                	 System.out.println();        
                	 System.out.println("|------------------------------------------------------------------------------------------------------------------------------------------------|");
                	 System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|");
                	 System.out.println("|  Numero  |    Nome    |  Tipo Reserva  | Turista| Qty Pessaos |  Data Entrada |   Data Saida| Valor a Pagar (USD) | Valor a Pagar (MT)|");
                	 System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|");
                	 System.out.printf("|%17s|%12s|%12s|%19s|%19s|%20s|%19s|%19s| %20s|\n", array[i].getTelefone(),array[i].getNomeCliente(),array[i].getTipoReserva(),array[i].getTurista(), array[i].getNumPessoas(), array[i].getDataEntrada(),array[i].getDataSaida(), usd.format(array[i].getValPagar()), array[i].getValPagarMT());
                	 System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|--------------------|");
                	 System.out.println("|--------------------------------------------------------------------------------------------------------------------------------------------------------------------|");
                	 System.out.println();
                 }
         }
	}

	public void visualizarTodasReservas(Reserva[] array, int cont) {
		// TODO Auto-generated method stub
		for(int i = 0; i < cont; i++)
		{
			if(array[i].getTipoReserva().equalsIgnoreCase("empresa"))
			{
				System.out.println();
	            System.out.println("|------------------------------------------------------------------------------------------------------------------------------------------------|");
				System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|");
				System.out.println("|  Numero Cell |    Nome    |  Tipo Reserva  | Qty Pessoas| Data Entrada |  Data Saida |   Valor a Pagar(USD)| Valor a Pagar(Mt) |");
				System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|");
				System.out.printf("|%17s|%12s|%12s|%19d|%19s|%20s|%19s|%19s|\n", array[i].getTelefone(),array[i].getNomeCliente(),array[i].getTipoReserva(), array[i].getNumPessoas(), array[i].getDataEntrada(),array[i].getDataSaida(),usd.format(array[i].getValPagar()),mt.format(array[i].getValPagarMT()));
				System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|");
				System.out.println("|------------------------------------------------------------------------------------------------------------------------------------------------|");
				System.out.println();
			} else if(array[i].getTipoReserva().equalsIgnoreCase("casal"))
			{
				System.out.println();
                System.out.println("|------------------------------------------------------------------------------------------------------------------------------------------------|");
                System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|");
                System.out.println("|  Numero Cell |    Nome    |  Tipo Reserva  | Qty Pessoas| Data Entrada |  Data Saida |   Valor a Pagar(USD)| Valor a Pagar(Mt) |");
                System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|");
                System.out.printf("|%17s|%12s|%12s|%19d|%19s|%20s|%19s|%19s|\n", array[i].getTelefone(),array[i].getNomeCliente(),array[i].getTipoReserva(), array[i].getNumPessoas(), array[i].getDataEntrada(),array[i].getDataSaida(),usd.format(array[i].getValPagar()),usd.format(array[i].getValPagarMT()));
                System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|");
                System.out.println("|------------------------------------------------------------------------------------------------------------------------------------------------|");
				System.out.println();
			} else if(array[i].getTipoReserva().equalsIgnoreCase("particular"))
			{
				System.out.println();
                System.out.println("|------------------------------------------------------------------------------------------------------------------------------------------------|");
                System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|");
                System.out.println("|  Numero Cell |    Nome    |  Tipo Reserva  | Qty Pessoas| Data Entrada |  Data Saida |   Valor a Pagar(USD)| Valor a Pagar(Mt) |");
                System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|");
                System.out.printf("|%17s|%12s|%12s|%19d|%19s|%20s|%19s|%19s|\n", array[i].getTelefone(),array[i].getNomeCliente(),array[i].getTipoReserva(), array[i].getNumPessoas(), array[i].getDataEntrada(),array[i].getDataSaida(),usd.format(array[i].getValPagar()),usd.format(array[i].getValPagar()));
                System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|");
                System.out.println("|------------------------------------------------------------------------------------------------------------------------------------------------|");
				System.out.println();
			}
		}
	}

	public void visualizarReservaNumTipo(int i, Reserva[] array, int cont) {
		// TODO Auto-generated method stub
		if(i== 1)
			System.out.println("Reserva não encontrada");
		else
		{
			System.out.println();
			System.out.println("|------------------------------------------------------------------------------------------------------------------------------------------------|");
			System.out.println("|------------------------------------------------------------------------------------------------------------------------------------------------|");
			System.out.println("|  Numero |    Nome    |  Tipo Reserva  |       Turista      | Data Entrada |  Data Saida |   Valor a Pagar (USD) | Valor a Pagar (MTS) |");
			System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|");
			System.out.printf("|%17s|%12s|%12s|%19s|%19s|%20s|%19s|%19s|\n", array[i].getTelefone(),array[i].getNomeCliente(),array[i].getTipoReserva(), array[i].getTurista(), array[i].getDataEntrada(), array[i].getDataSaida(), usd.format(array[i].getValPagar()), mt.format(array[i].getValPagarMT()));
			System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|");
			System.out.println("|------------------------------------------------------------------------------------------------------------------------------------------------|");
			System.out.println();
		}
			
	}

	public void visualizarPeloTipoNum(int i, Reserva[] array) {
		// TODO Auto-generated method stub
		System.out.println("|------------------------------------------------------------------------------------------------------------------------------------------------|");
		System.out.println("|------------------------------------------------------------------------------------------------------------------------------------------------|");
		System.out.println("|  Numero |    Nome    |  Tipo Reserva  |       Turista      | Data Entrada |  Data Saida |   Valor a Pagar (USD) | Valor a Pagar (MTS) |");
		System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|");
		System.out.printf("|%17s|%12s|%12s|%19s|%19s|%20s|%19s|%19s|\n", array[i].getTelefone(),array[i].getNomeCliente(),array[i].getTipoReserva(), array[i].getTurista(), array[i].getDataEntrada(), array[i].getDataSaida(), usd.format(array[i].getValPagar()), mt.format(array[i].getValPagarMT()));
		System.out.println("|-----------------|------------|------------|-------------------|-------------------|--------------------|-------------------|-------------------|");
		System.out.println("|------------------------------------------------------------------------------------------------------------------------------------------------|");
		
		System.out.println();
	}

}
