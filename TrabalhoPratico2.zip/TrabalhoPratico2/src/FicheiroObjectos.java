import java.io.*;
public class FicheiroObjectos {
	public FicheiroObjectos()
	{
		
	}

	public void escreverFicheiroObjectos(Reserva[] array, int cont) {
		// TODO Auto-generated method stub
		try
		{
			 FileOutputStream f = new FileOutputStream("ReservaObjecto.dat");
             ObjectOutputStream o = new ObjectOutputStream(f);

             o.writeObject(array);
             o.close();
		} catch(IOException e)
		{
			System.out.println(e.getMessage());
		}
		System.out.println("Ficheiro de objectos criado com sucesso! Abra para ver os Dados!");
	}
	
}
