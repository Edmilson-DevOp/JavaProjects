import java.io.*;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;
public class EscreverFicheiro {
	private DecimalFormat df;
    private NumberFormat nf;
    
	public EscreverFicheiro()
	{
		df = new DecimalFormat("###,###.00 MTS");
        nf = NumberFormat.getCurrencyInstance(Locale.US);
	}
	
	public void escreverFicheiro(float empresa, float casal, float particular, float valEmp, float valCas, float valPart) {
		// TODO Auto-generated method stub
		try
		{
			 FileWriter fw = new FileWriter("ValorTotal.txt");
             BufferedWriter bw = new BufferedWriter(fw);
             bw.write("|Valor de Empresa: "+nf.format(empresa)+ "  | Valor de Casal: "+nf.format(casal)+" |Valor de Particular: "+nf.format(particular));
             bw.write("|Valor de Empresa: "+df.format(valEmp)+ " |Valor de Casal: "+df.format(valCas)+" Pessoal: "+df.format(valPart));
             bw.close();
		} catch(IOException e)
		{
			System.out.println(e.getMessage());
		}
		System.out.println("Ficheiro criado com sucesso! veja os valores nos Ficheiros");
	}

	public void escreverNovaReserva() {
		// TODO Auto-generated method stub
		  Reserva[] array = new Reserva[25];
		  Validacoes val = new Validacoes();
          
          int telefone=0, quantidade =0; 
          String nome= "", tipo = "", turista =" ", dataEntrada = "", dataSaida = "";
          float valorPagar =0;
          
          telefone = val.validarInteiros(820000000, 879999999, "Introduza o numero de telefone:");
          nome = val.validarString("Introduza o nome");
          tipo = val.validarTipoReserva("Insira o tipo de Reserva que prentende entre |EMPRESA| Casal | Particular|", "Empresa", "Casal", "Particular");
          switch(tipo)
          {
                      
              case "Empresa" :
                                  
                                      dataEntrada = val.validarString("Intoduza  a data de entrada: Ex: [2024/07/20]: ");
                                      dataSaida = val.validarString("Intoduza a data de saida: Ex: [2024/07/30]:");
                                      quantidade = val.validarInt("Introduza o numero de pessoas: [ > = 15]");
                                      turista = "Nao";
                                      
              case "Casal" :
                                      
                                         dataEntrada = val.validarString("Intoduza  a data de entrada: Ex: [2024/07/20]: ");
                                         dataSaida = val.validarString("Intoduza  a data de entrada: Ex: [2024/07/30]: ");
                                         quantidade = val.validarInt("Introduza o numero de pessoas: [=2]");
                                         turista = val.validarTurista("È Turista?", "Sim", "Nao");
              case "Particular" :
                                      
                                         dataEntrada = val.validarString("Intoduza  a data de entrada: Ex: [2024/07/20]: ");
                                         dataSaida = val.validarString("Intoduza  a data de entrada: Ex: [2024/07/30]: ");
                                         quantidade = val.validarInt("Introduza o numero de pessoas: [>0]");
                                         turista = val.validarTurista("È Turista?", "Sim", "Nao");
          }
          
          try
          {
        	  FileWriter fw = new FileWriter ("NovasReservas.txt");
              BufferedWriter bw = new BufferedWriter(fw);
              
              bw.write("| Numero de celular: "+telefone+"| nome: " + nome+"|TipoReserva: " +tipo+ "| Turista: "+turista +
                      "| Data de Entrada: "+dataEntrada+ "| Data de Saida :  "+dataSaida+"| Quantidade de pessoas:" + quantidade);
              bw.close();
          } catch(IOException e)
          {
        	  System.out.println(e.getMessage());
          }
          System.out.println("Dados adicionados com sucesso, ao ficheiro de Objecto.");
         
	}

}
