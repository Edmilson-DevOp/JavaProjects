
public class Menu {
    private Validacoes val;
	private TodasReservas t;
	private Visualizacoes vis;
    private EscreverFicheiro e;
    
    public Menu()
    {
    	t = new TodasReservas();
        val = new Validacoes();
        vis = new Visualizacoes();
        e = new EscreverFicheiro();
    }
    
    public void run()
    {
    	int opcao, opcao2, opcao3;
        boolean passagem=false;
        
        do
        {
        	vis.menuOpcoes();
            opcao = val.validarInteiros(1, 10, "Insira a Opcao que deseja no menu!");
            switch(opcao)
            {
            case 1:
            	t.lerFicheiro("Reservas.txt");
            	passagem = true;
            	break;
            case 2:
            	if(passagem == false)
            		System.out.println("Primeiro escolha a opção 1!");
            	else
            	{
            		do
            		{
            			vis.subMenu();
                		opcao2 = val.validarInteiros(1, 4, "Escolha a Opcao!");
                		switch(opcao2)
                		{
                		case 1:
                			t.adaptadorVisualizarEmpresa();
                			break;
                		case 2:
                			t.adaptadorVisualizarCasal();
                            break;
                        case 3:
                        	t.adaptadorVisualizarParticular();
                            break;
                		}
            		} while(opcao2 != 4);
            	}
            	System.out.println(t);
                t.adptadorVisualizarTodasReservas();
                System.out.println("Todas reservas do Maricell Lodge!");
            	break;
            case 3:
            	if(passagem == false)
            		System.out.println("Primeiro escolha a opção 1!");
            	else
            	{
            		do
            		{
            			vis.subMenu();
                        opcao3 = val.validarInteiros(1, 4, "Introduza a opcao a sua escolha!");
                        switch(opcao3)
                        {
                        case 1:   
                            t.adaptadorQuantidadesReservasEmpresa();
                            break;
                        case 2:
                        	 t.adaptadorQuantidadesReservasCasal();
                            break;
                        case 3:
                        	 t.adaptadorQuantidadesReservasParticular();
                            break;
                        }
            		} while(opcao3 != 4);
            	}
            	break;
            case 4:
            	System.out.println("Case não resolvido!");
            	break;
            case 5:
            	if(passagem == true)
            		System.out.println("Primeiro escolha a opção 1!");
            	else
            		t.adptadorEscreverValTotal();
            	break;
            case 6:
            	if(passagem == false)
            		System.out.println("Primeiro escolha a opção 1");
            	else
            		t.adptadorEscreverDados();
            	break;
            case 7:
            	if(passagem == false)
            		System.out.println("Primeiro escolha a opção 1");
            	else
            		t.adptadorPesquisarReserva();
            	break;
            case 8:
            	t.adptadorOrdenarReserva();
            	break;
            case 9:
            	t.adptadorNovaReserva();
            	break;
            case 10:
            	System.out.println("Obrigado, volte sempre!");
            	break;
            default: System.out.println("Opção inválida");
            }
        } while(opcao != 10);
    }
}
