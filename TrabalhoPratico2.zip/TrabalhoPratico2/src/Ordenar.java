import java.util.*;
public class Ordenar {
	public Ordenar()
	{
		
	}
	
	public void ordenarReserva(Reserva[] array, int cont) {
		// TODO Auto-generated method stub
		for(int i = 0; i < cont-1; i++)
		{
			for(int j = 0; j < cont; j++)
			{
				String dataSaida = array[i].getDataSaida();
                String dataSaida2 = array[j].getDataSaida();
                
                
                StringTokenizer st = new StringTokenizer(dataSaida, "/");
                StringTokenizer st2 = new StringTokenizer(dataSaida2, "/"); 
                
                int dia = Integer.parseInt(st.nextToken());
                int dia2 = Integer.parseInt(st2.nextToken());
                
                if(dia < dia2)
                {
                	Reserva temporario = array[i];
                    array[i] = array[j];
                    array[j] = temporario;
                }
			}
		}
	}

}
