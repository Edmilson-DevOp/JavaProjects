/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
*
* @author Edmilson Leandro, Ayko Sambo, Ilundy Simbine
*/
import java.util.*;
import java.io.*;
public class TodasReservas {
	//Atributos
	private Reserva [] array;
	int cont;
	private Calculos cal;
    private Visualizacoes vis;
                        
    public TodasReservas()
    {
    	array = new Reserva[50];
        cont =0;
        cal = new Calculos();
        vis= new Visualizacoes();
    }
                        
    public void lerFicheiro(String nomeFicheiro)
    {
    	 int telefone, numPessoas;
         String nome, tipo, turista, dataEntrada, dataSaida, umaLinha, praia, piscina;
         float valorPagar;
         StringTokenizer umaCadeia;
                            
         try
         {
        	 FileReader fr = new FileReader(nomeFicheiro);
             BufferedReader br = new BufferedReader(fr);
             umaLinha = br.readLine();
                                        
             while(umaLinha != null)
             {
            	 umaCadeia = new StringTokenizer(umaLinha,";");
            	 numPessoas = Integer.parseInt(umaCadeia.nextToken());
                 telefone = Integer.parseInt(umaCadeia.nextToken());
                 nome = umaCadeia.nextToken();
                 tipo = umaCadeia.nextToken();
                 turista = umaCadeia.nextToken();
                 dataEntrada = umaCadeia.nextToken();
                 dataSaida = umaCadeia.nextToken();
                 praia = umaCadeia.nextToken();
                 piscina = umaCadeia.nextToken();
                 array[cont] = new Reserva(numPessoas, telefone, nome, tipo, turista, dataEntrada, dataSaida, praia, piscina);
                 cont++;
                 umaLinha = br.readLine();
              }
              br.close();
        }catch(FileNotFoundException e)
        {
          System.out.println("Ficheiro "+nomeFicheiro+" não encontrado");
        }catch(NumberFormatException e)
        {
        	System.out.println(e.getMessage());
        }catch(IOException e)
        {
        	System.out.println(e.getMessage());
        }
    }
     
     public String toString()
     {
         return vis.toString(array,cont);
     }
     
     public void adptadorVisualizarTodasReservas()
     {
    	 vis.visualizarTodasReservas(array, cont);
     }
     
 	public void adaptadorVisualizarEmpresa() {
 		// TODO Auto-generated method stub
 		vis.visualizarReservasEmpresa(array, cont);
 	}

 	public void adaptadorVisualizarCasal() {
 		// TODO Auto-generated method stub
 		vis.visualizarReservasCasal(array, cont);
 	}

 	public void adaptadorVisualizarParticular() {
 		// TODO Auto-generated method stub
 		vis.visualizarReservasParticular(array, cont);
 	}
 	
 	 public void adaptadorQuantidadesReservasEmpresa()
     {
    	 int contE = cal.calcularQuantidadesReservaTipo(array, cont, "Empresa");
    	 vis.visualizarQuantidades(contE, "Empresa");
     }
 	 
 	public void adaptadorQuantidadesReservasCasal()
    {
   	 int contC = cal.calcularQuantidadesReservaTipo(array, cont, "Casal");
   	 vis.visualizarQuantidades(contC, "casal");
    }
 	
 	public void adaptadorQuantidadesReservasParticular()
    {
   	 int contP = cal.calcularQuantidadesReservaTipo(array, cont, "particular");
   	 vis.visualizarQuantidades(contP, "particular");
    }
 	
 	public void adptadorEscreverValTotal() {
		// TODO Auto-generated method stub
 		EscreverFicheiro e = new EscreverFicheiro();
 		float dolarEmpresa, dolarCasal, dolarParticular, mtEmpresa, mtCasal, mtParticular=0;
 		dolarEmpresa = cal.calcularValTotal(array, cont, "empresa");
 		dolarCasal = cal.calcularValTotal(array, cont, "empresa");
 		dolarParticular = cal.calcularValTotal(array, cont, "empresa");
 		mtEmpresa = cal.convMoeda(dolarEmpresa);
 		mtCasal = cal.convMoeda(dolarCasal);
 		mtParticular = cal.convMoeda(dolarParticular);
 		e.escreverFicheiro(dolarEmpresa, dolarCasal, dolarParticular, mtEmpresa, mtCasal, mtParticular);
 				
	}
 	
 	public void adptadorEscreverDados() {
		// TODO Auto-generated method stub
		FicheiroObjectos f = new FicheiroObjectos();
		f.escreverFicheiroObjectos(array, cont);
	}
 	
 	public void adptadorPesquisarReserva() {
		// TODO Auto-generated method stub
		cal.pesquisarReserva(array, cont);
	}
 	
 	
 	public void adptadorOrdenarReserva() {
		// TODO Auto-generated method stub
		OrdenarReserva o = new OrdenarReserva();
		o.ordernarReserva(array, cont);
	}

	public void adptadorNovaReserva() {
		// TODO Auto-generated method stub
		EscreverFicheiro e = new EscreverFicheiro();
		e.escreverNovaReserva();
	}
}
