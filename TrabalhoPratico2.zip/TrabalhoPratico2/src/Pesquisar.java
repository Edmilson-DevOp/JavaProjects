
public class Pesquisar {
	private Validacoes val;
	
	public Pesquisar()
	{
		val = new Validacoes();
	}

	public void pesquisarNumeroTipoReserva(Reserva[] array, int cont, int numero, String tipo)
	{
		// TODO Auto-generated method stub
		numero = val.validarInteiros(820000000,879999999, "Introduza o Numero de Telefone");
        tipo = val.validarTipoReserva("Empresa", "Casal", "Particular", "Introduza uma das opcoes para a Pesquisa");
        boolean busca = false;
        
        for(int i=0;i<cont && busca==false;i++)
        {
        	if(array[i].getTelefone() ==  numero && array[i].getTipoReserva().equalsIgnoreCase(tipo))
            {
              busca = true;
              System.out.println(array[i]);
            }
        }
	}

}
