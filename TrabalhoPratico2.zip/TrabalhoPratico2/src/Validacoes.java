import java.io.*;

public class Validacoes {
	private BufferedReader br;
	
	public Validacoes()
	{
		br = new BufferedReader(new InputStreamReader(System.in));
	}
	
	public int validarInteiros(int min, int max, String msg) 
	{
		// TODO Auto-generated method stub
		int val = 0;
		do
		{
			System.out.println(msg);
			try
			{
				val = Integer.parseInt(br.readLine());
			} catch(NumberFormatException e)
			{
				System.out.println(e.getMessage());
			} catch(IOException e)
			{
				System.out.println(e.getMessage());
			}
			if(val < min || val > max)
				System.out.println("Número inválido!");
		} while(val < min || val > max);
        return val;
	}

	public String validarTipoReserva(String empresa, String casal, String particular, String msg) {
		// TODO Auto-generated method stub
		 String tipo = " ";
         
         do 
         {
        	 System.out.println(msg);
             try
             {
            	 tipo = br.readLine();
             }catch(IOException e) 
             {
            	 System.out.println(e.getMessage());
            }
            if(!tipo.equalsIgnoreCase(empresa) && !tipo.equalsIgnoreCase(casal) && !tipo.equalsIgnoreCase(particular))
            	System.out.println("Invalido escolhe ("+empresa+" ou "+casal+" ou "+particular+")");
          }while(!tipo.equalsIgnoreCase(empresa) && !tipo.equalsIgnoreCase(casal) && !tipo.equalsIgnoreCase(particular));
           return tipo;
	}

	public String validarString(String msg) {
		// TODO Auto-generated method stub
		String val = " ";
		do
		{
			System.out.println(msg);
			try
			{
				val = br.readLine();
			} catch(IOException e)
			{
				System.out.println(e.getMessage());
			}
			if(val.length() < 2)
				System.out.println("Inválido!");
		} while(val.length() < 2);
		return val;
	}

	public int validarInt(String msg) {
		// TODO Auto-generated method stub
		int val = 0;
		do
		{
			System.out.println(msg);
			try
			{
				val = Integer.parseInt(br.readLine());
			} catch(NumberFormatException e)
			{
				System.out.println(e.getMessage());
			} catch(IOException e)
			{
				System.out.println(e.getMessage());
			}
			if(val < 0)
				System.out.println("Número inválido!");
		} while(val < 0);
		return val;
	}

	public String validarTurista(String msg, String sim, String nao) {
		// TODO Auto-generated method stub
		String val = " ";
		do
		{
			System.out.println(msg);
			try
			{
				val = br.readLine();
			} catch(IOException e)
			{
				System.out.println(e.getMessage());
			}
			if(!val.equalsIgnoreCase(sim) && !val.equalsIgnoreCase(nao))
				System.out.println("Inválido!");
		} while(!val.equalsIgnoreCase(sim) && !val.equalsIgnoreCase(nao));
		return val;
	}

}
