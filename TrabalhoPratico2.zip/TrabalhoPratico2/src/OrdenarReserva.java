import java.util.*;
public class OrdenarReserva {
	public OrdenarReserva()
	{
		
	}

	public void ordernarReserva(Reserva[] array, int cont) {
		// TODO Auto-generated method stub
		for(int i = 0; i < cont-1; i++)
		{
			for(int j = 0; j < cont; j++)
			{
				 StringTokenizer s = new StringTokenizer(array[i].getDataSaida(), "/");
                 StringTokenizer s2 = new StringTokenizer(array[j].getDataSaida(), "/"); 
                 int dia = Integer.parseInt(s.nextToken());
                 int dia2 = Integer.parseInt(s2.nextToken());
                 
                 if(dia < dia2)
                 {
                	 Reserva temp = array[i];
                     array[i] = array[j];
                     array[j] = temp;
                 }
			}
		}
	}
}
