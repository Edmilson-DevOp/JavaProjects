import java.io.*;
public class FicheiroObjecto {
	public FicheiroObjecto()
	{
		
	}

	public void escreverObjectos(Reserva[] array, int cont) {
		// TODO Auto-generated method stub
		try
        { 
			FileOutputStream fos = new FileOutputStream("ReservaObjecto.dat");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(array);
            oos.close();
        } catch (IOException ioe)
        {
            System.out.println(ioe.getMessage());
        }
  
    System.out.println("Ficheiro de objectos criado com sucesso! Abra para ver os Dados!SS");
	}

}
