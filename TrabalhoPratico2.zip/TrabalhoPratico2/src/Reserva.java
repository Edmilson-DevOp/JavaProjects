/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Edmilson Leandro, Ayko Sambo, Ilundy Simbine
 */
import java.io.*;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;
public class Reserva {
	//Atributos
	private int telefone, numPessoas, numDias, entrada, saida;
    private String nomeCliente, tipoReserva, turista, praia, piscina, dataEntrada, dataSaida;
    private float valPagar, valPagarMT, imposto, extra, desconto, valFinal;
    private DecimalFormat mt;
    private NumberFormat usd;

    //Constructor
    public Reserva()
    {
    	mt = new DecimalFormat("###,###. 00MTS");
        usd =  NumberFormat.getCurrencyInstance(Locale.US);
    }

    //Constructor para leitura do Ficheiro
    public Reserva(int numPessoas, int telefone, String nomeCliente, String tipoReserva, String turista, String dataEntrada, String dataSaida, String praia, String piscina)
    {
    	this.numPessoas = numPessoas;
    	this.telefone = telefone;
        this.nomeCliente = nomeCliente;
        this.tipoReserva = tipoReserva;
        this.turista = turista;
        this.dataEntrada = dataEntrada;
        this.dataSaida = dataSaida;
        this.praia = praia;
        this.piscina = piscina;
        entrada = convParaInt(dataEntrada);
        saida = convParaInt(dataSaida);
        mt = new DecimalFormat("###,###. 00MTS");
        usd =  NumberFormat.getCurrencyInstance(Locale.US);
    }
    
    //Metodo de calculo
    public int convParaInt(String data)
    {
    	return Integer.parseInt(data.substring(8, 10));
    }
    
    public int numDias()
    {
    	int saida = Integer.parseInt(dataSaida.substring(8, 10));
    	int entrada = Integer.parseInt(dataEntrada.substring(8, 10));
    	return numDias = saida - entrada;
    }

    public float calcularValPagar()
    {                                       
        final int EMPRESA = 100, CASAL = 80, PARTICULAR = 40; 
       

        switch(tipoReserva)
        {
        case "empresa":
        	valPagar = EMPRESA *  numDias() * numPessoas;
        	break;
        case "casal":
        	valPagar = CASAL *  numDias() * numPessoas;
        	break;
        case "particular":
        	valPagar = PARTICULAR *  numDias() * numPessoas;
        	break;
        }
        return valPagar;
    }
                           
    public float calcularExtra()
    {        
    	final float PRAIA = 50, PISCINA =35;
        
        if(praia.equalsIgnoreCase("Sim"))
        	extra = PRAIA;
        else if(piscina.equalsIgnoreCase("Sim"))
           extra = PISCINA;
        else if(praia.equalsIgnoreCase("Sim") && piscina.equalsIgnoreCase("Sim"))
        	extra =  PRAIA + PISCINA;
        return extra;
    }
                           
    public float Feriado()
    {
         final float DESC = 23/100f;
         
         for(int i = entrada; i<=saida;i+=1)
         {
                 if(i != 7 && i !=25)
                     return desconto = valPagar*DESC;
         }
         return desconto;
    }
                           
    public float calcularImposto()
    {
        final float IMPOSTO_EMPRESA = 10/100f, IMPOSTO_TURISTA = 3/100f;
        if(tipoReserva.equalsIgnoreCase("empresa"))
        	imposto = valPagar*IMPOSTO_EMPRESA;
        else if(turista.equalsIgnoreCase("sim"))
        {
        	if(tipoReserva.equalsIgnoreCase("casal") && tipoReserva.equalsIgnoreCase("particular"))
        		imposto = valPagar*IMPOSTO_TURISTA;
        }
        return imposto;
    }
    
    public float calcularValorFinal()
    {
        return valFinal = (valPagar + imposto + extra) - desconto;
        
    }
    
    public float convParaMT()
    {
    	final int USD = 65;
    	return valPagarMT = USD*valPagar;
    }
    
    //Metodos de acesso
    public float getValPagar() {
		// TODO Auto-generated method stub
		return valPagar;
	}
    
    public float getValPagarMT()
    {
    	return valPagarMT;
    }
    
    public String getTipoReserva() {
		// TODO Auto-generated method stub
		return tipoReserva;
	}

	public int getNumPessoas() {
		// TODO Auto-generated method stub
		return numPessoas;
	}

	public String getDataEntrada() {
		// TODO Auto-generated method stub
		return dataEntrada;
	}

	public String getNomeCliente() {
		// TODO Auto-generated method stub
		return nomeCliente;
	}

	public String getDataSaida() {
		// TODO Auto-generated method stub
		return dataSaida;
	}

	public int getTelefone() {
		// TODO Auto-generated method stub
		return telefone;
	} 
	
	public String getTurista() {
		// TODO Auto-generated method stub
		return turista;
	}
	
	public float getValFinal() {
		// TODO Auto-generated method stub
		return valFinal;
	}
   
    public String toString()
    {
    	return "|Quantidade de pessoas: " +numPessoas+" | Numero:" +telefone+"| Nome:" +nomeCliente+"| Tipo de Reserva:"+tipoReserva+ "| Turista: "+turista+ 
    			"|Data Entrada: "+ dataEntrada +"| Data Saida: "+ dataSaida + "Praia:" +praia+ "| Piscina: "+ piscina+" | " ;     
    }

}